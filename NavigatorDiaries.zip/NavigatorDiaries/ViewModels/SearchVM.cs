﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NavigatorDiaries.Views
{
    public class SearchVM
    {
        public string Titel { get; set; }
        public string Details { get; set; }
        public string Image { get; set; }
        public bool IsSelected { get; set; }

    }
}
