﻿using System;
using System.ComponentModel;
using System.Windows.Input;
using NavigatorDiaries.Views;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace NavigatorDiaries.Views
{
    public static class LoginVM 
    {
        public static string Username = "Sandeepa";
        public static string Password = "Sandeepa";
    }
}
